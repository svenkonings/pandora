Kraak het wachtwoord en scoor bonuspunten!

Als je de bijgeleverde interpreter gebruikt moet je "ignore errors" aanvinken.
Als het wachtwoord correct is ingevuld komt er logisch leesbare tekst uit rollen; wanneer er gibberish uit komt zit je gewoon fout, dat is een resultaat van sloppy brainfuck code, geen stap in de goede richting.